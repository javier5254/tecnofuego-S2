-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 34.95.168.120    Database: SIRAC2
-- ------------------------------------------------------
-- Server version	5.7.34-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `typeD_id` bigint(20) unsigned DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_typed_id_foreign` (`typeD_id`),
  KEY `users_charge_id_foreign` (`charge_id`),
  KEY `users_client_id_foreign` (`client_id`),
  KEY `users_project_id_foreign` (`project_id`),
  CONSTRAINT `users_charge_id_foreign` FOREIGN KEY (`charge_id`) REFERENCES `valists` (`id`),
  CONSTRAINT `users_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `users_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  CONSTRAINT `users_typed_id_foreign` FOREIGN KEY (`typeD_id`) REFERENCES `valists` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Javier Esteban Mora Osorio','123','javier.esteban.mora@gmail.com',NULL,'$2y$10$OAihiCrdxk3eptDfYIesSO/bXMY7ns9NnH7l79pWHTn.WqzlywQXu',NULL,NULL,NULL,NULL,'ImagesUsers/QU9U2uNMQ2Selh3wRXL0q6EqKaxurysJc11Grcpu.svg',1,'2021-06-03 19:58:21','2021-09-02 17:49:41',NULL,NULL,NULL,NULL),(2,'tester','123','tester@gmail.com',NULL,'$2y$10$7d97HYikoTH.AsJHi1Qbtumt7UKLs5f2aTsPYbm/hgo9pcWroaMTm',NULL,NULL,NULL,NULL,NULL,1,'2021-06-03 19:58:22','2021-06-03 19:58:22',NULL,NULL,NULL,NULL),(3,'Javier Antonio Arroyo De Hoyos','78305037','jarroyo@tecno-fuego.com.co',NULL,'$2y$10$EwFk6VltZ/bN9Ne5XXRkiO21HNuW8wmfUD6/41p53.UoBDWktueke',NULL,NULL,'7FDApu0N7NVQeejC0uTUDbhKazkdWMx9FXQeKpASHCYMwPuDnKhLEQbh4M2q',NULL,NULL,1,'2021-06-03 19:58:22','2021-06-12 23:18:37',2,5,NULL,NULL),(4,'Carlos Peñaranda','1140816136','cpenaranda@tecno-fuego.com.co',NULL,'$2y$10$19mQbzq1TlysJBfbcIGPOebwRzjyyNwZbghnTazYLMa5rr.PJDy1e',NULL,NULL,'sRBrSv0kUqPc7t3XkLANSWYzIHlqjSdIJeT7X8EK9Ujkd1Nc77RDAusRhVgU',NULL,NULL,1,'2021-06-03 19:58:22','2021-09-10 19:52:04',NULL,NULL,NULL,NULL),(5,'Javier Alfonso Mercado Archibold','72272972','jmercado@tecno-fuego.com.co',NULL,'$2y$10$Syn23Y6yotJOU3cloDqTS.usWBSRFbBa28PydPdsOncudnBr/.gn6',NULL,NULL,'90OjvLBBjdbvb8ksjHzcoE7IFFhYDquQ5a0JkM0MdXeITEml8ZeE0w8BzNVN',NULL,'',1,'2021-06-12 23:17:51','2021-09-18 15:03:41',2,5,1,1),(6,'Freddy Arturo De La Hoz Mercado','72054429','fdelahoz@tecno-fuego.com.co',NULL,'$2y$10$VKSSEn6dk/68BxWmQQSgK.o6KJvQpUrq1TRVsd3EABV3meDbL1UQe',NULL,NULL,NULL,NULL,'',1,'2021-06-12 23:19:45','2021-06-12 23:21:30',2,8,1,1),(7,'Wilman Antonio Ojeda Navarro','72257092','wojeda@tecno-fuego.com.co',NULL,'$2y$10$/g/DjuIKYiiOVJGdx946Gu9gnoFaCsHVQCrFmFTbp/niby5aV6fpu',NULL,NULL,'welIkiwfHX76exGtvSBsBGQ50hjIEUcPAMnNBFb8ZaMKC8JLa7rdkMoPCN1b',NULL,'',1,'2021-06-12 23:21:03','2021-09-18 15:01:05',2,8,1,1),(8,'Deivis Enrique Acendra Alvarez','72258245','dacendra@tecno-fuego.com.co',NULL,'$2y$10$yyt8rgBFUHfOMV5DeL29OuMjLWJzoST3.NZEfG5pvyCGeZrptrCCS',NULL,NULL,NULL,NULL,'',1,'2021-06-12 23:22:16','2021-06-12 23:22:16',2,8,1,1),(9,'Edward Mauricio Correa Herreño','13871392','ecorrea@tecno-fuego.com.co',NULL,'$2y$10$kzuSXdEx6K8QJ2bHmHwxguEj4LLIC/KEGPbK2bM5P9MM1lXwEGvwm',NULL,NULL,'nBJwDVsd4FvHR3nuY48hdVqfkCrt9s5ABXC6H1Vj8VeY8xhra8YGnlCQ67AK',NULL,'',1,'2021-06-12 23:23:17','2021-09-21 03:13:02',2,8,1,1),(10,'Alberto Villafañe Perez','72348522','avillafane@tecno-fuego.com.co',NULL,'$2y$10$.oEmq/pg5eRqaYlnrtVg5eEyMf.NJVM1NsYcfebZmvjn9yvMjIUyS',NULL,NULL,'A0oY5c6evfYeX2ECO8oy7Nnd0FYpVMiBofKFFTKTutCPsnZXtciA5VYmzHUg',NULL,'',1,'2021-07-14 20:35:23','2021-09-10 21:49:13',2,7,1,1),(11,'Oscar Castillo','1129583416','ocastillo@tecno-fuego.com.co',NULL,'$2y$10$4KYpmZzemR/xhhyg1NORu.xqxO0JcEKIknxx8GN6CiJP9cU1IbWTm',NULL,NULL,NULL,NULL,'',1,'2021-07-23 21:45:15','2021-07-23 21:45:15',2,7,NULL,NULL),(12,'Alberto Torres Padilla','12693335','atorres@tecno-fuego.com.co',NULL,'$2y$10$TJl.74WYSlQ7bz755oRXS.eZrUP3XQcJ97ERWCMxnUKaj.H8bJl/6',NULL,NULL,NULL,NULL,'',1,'2021-08-27 16:23:15','2021-08-30 22:24:59',2,4,1,1),(13,'Ricardo Garcia pedrozo','1234088652','rgarcia@tecno-fuego.com.co',NULL,'$2y$10$9lznlsf1P2fVuRNFSBNAzeyUFp2.0drDim8swAysJpfU2jWS0Dr2K',NULL,NULL,NULL,NULL,'',1,'2021-08-27 18:43:42','2021-08-30 22:24:22',2,4,1,1),(14,'Prueba 2','2313213','prueba@tecno-fuego.com.co',NULL,'$2y$10$yswUtOdYMYuHgQn2s9tGOeE/mQDNIJqRQXvPt.T3Eeu//c8ck.KeO',NULL,NULL,NULL,NULL,'',1,'2021-08-30 20:28:29','2021-08-30 20:28:29',2,4,1,1),(15,'PRUEBA 5','2313213','capenaranda@tecno-fuego.com.co',NULL,'$2y$10$dUTfUTYsksb13aXM/E2qN.7F1Dvu6XdQzS3Sh3n1fnP.CvMX0lzZy',NULL,NULL,NULL,NULL,'',1,'2021-09-06 23:39:28','2021-09-06 23:39:28',2,5,2,2),(16,'Hector Luis Martinez Mene','1064113868','hlmmeneses@gmail.com',NULL,'$2y$10$dEns7hxWEmYY6Rbpt6Gkl.uclX5Me11jQi7wSdhWJUNCopJPz0nni',NULL,NULL,'W9QnguUoDBmWnq2uU6XLIoonVspk9LKnDpEkJfDy9ErWPs0QTmBBdaDQJk2I',NULL,'',1,'2021-09-18 15:04:29','2021-09-18 15:04:29',2,6,1,1),(17,'Jorge Torres Jimenez','72288617','jotoji316@gmail.com',NULL,'$2y$10$s2H8h0dkA.DXqJIpEJYdzewFzX441yhN2msVxKNnEdsc6CF1SIWK2',NULL,NULL,NULL,NULL,'',1,'2021-09-18 15:06:20','2021-09-18 15:06:20',2,6,1,1),(18,'Gabriel Antonio Zambrano Villa','8568709','grabielz2110@hotmail.com',NULL,'$2y$10$JGxcF.ABwiqSsgqep1O6c.0/84NmuIV44XTEHuTWkQo/OSdE87PBe',NULL,NULL,'iNXDbQyr9zkW4USorfKJU6mEvttGwsybUwAfVcvDbQ4uvWKpcFMEuesy1YpE',NULL,'',1,'2021-09-18 15:06:34','2021-09-18 15:06:34',2,6,1,1),(19,'Julio de la Asunción Hurtado','1042422734','giuler007@hotmail.com',NULL,'$2y$10$QWUNgCbZ//icEDlh.j1xgO8I8.26PlSnH.ENndlbgla8PI23IKX6u',NULL,NULL,NULL,NULL,'',1,'2021-09-18 15:08:02','2021-09-18 15:08:02',2,6,1,1),(20,'Alberto Rafael Salas Lopez','72490200','rschell_14@hotmail.com',NULL,'$2y$10$nea7thM87JSI5lwabCzjFOR8RmZL6emwBKgpMp85SFb4H/uDLIqH2',NULL,NULL,NULL,NULL,'',1,'2021-09-18 15:08:38','2021-09-18 15:08:38',2,6,1,1),(21,'Nicolás Rocha chegwin','8767809','nicolasrochachegwin@gmail.com',NULL,'$2y$10$aYwSKKLrdG9OfzQWinSQOOC0i2zoo5RGmJTzeNc7k2j5iJt2kJYJq',NULL,NULL,NULL,NULL,'',1,'2021-09-18 15:10:26','2021-09-18 15:10:26',2,6,1,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-20 14:05:18
