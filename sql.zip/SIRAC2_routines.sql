-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 34.95.168.120    Database: SIRAC2
-- ------------------------------------------------------
-- Server version	5.7.34-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!50001 DROP VIEW IF EXISTS `equipos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `equipos` AS SELECT 
 1 AS `Id_Equipo`,
 1 AS `No_Interno`,
 1 AS `Modelo`,
 1 AS `Flota`,
 1 AS `Marca`,
 1 AS `Cliente`,
 1 AS `Proyecto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `tecnicos`
--

DROP TABLE IF EXISTS `tecnicos`;
/*!50001 DROP VIEW IF EXISTS `tecnicos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `tecnicos` AS SELECT 
 1 AS `id_Tecnico`,
 1 AS `Nombre`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `componentes`
--

DROP TABLE IF EXISTS `componentes`;
/*!50001 DROP VIEW IF EXISTS `componentes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `componentes` AS SELECT 
 1 AS `Id_Equipo`,
 1 AS `Id_Compo`,
 1 AS `Consecutivo`,
 1 AS `Name`,
 1 AS `Familia`,
 1 AS `Categoria`,
 1 AS `State`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `statuscomp`
--

DROP TABLE IF EXISTS `statuscomp`;
/*!50001 DROP VIEW IF EXISTS `statuscomp`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `statuscomp` AS SELECT 
 1 AS `idComponent`,
 1 AS `Estatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `attrcomponentes`
--

DROP TABLE IF EXISTS `attrcomponentes`;
/*!50001 DROP VIEW IF EXISTS `attrcomponentes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `attrcomponentes` AS SELECT 
 1 AS `idCompo`,
 1 AS `label`,
 1 AS `val`,
 1 AS `idEquip`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `fact`
--

DROP TABLE IF EXISTS `fact`;
/*!50001 DROP VIEW IF EXISTS `fact`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `fact` AS SELECT 
 1 AS `IdAct`,
 1 AS `Fecha`,
 1 AS `Id_Equipo`,
 1 AS `Fecha_Inicio`,
 1 AS `Fecha_fin`,
 1 AS `Actividad`,
 1 AS `Hora_Inicio`,
 1 AS `Hora_Fin`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `otros_componentes`
--

DROP TABLE IF EXISTS `otros_componentes`;
/*!50001 DROP VIEW IF EXISTS `otros_componentes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `otros_componentes` AS SELECT 
 1 AS `IdEquip`,
 1 AS `idPart`,
 1 AS `val`,
 1 AS `description`,
 1 AS `attr`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `participacion`
--

DROP TABLE IF EXISTS `participacion`;
/*!50001 DROP VIEW IF EXISTS `participacion`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `participacion` AS SELECT 
 1 AS `id_Act`,
 1 AS `Id_Tecnico`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `equipos`
--

/*!50001 DROP VIEW IF EXISTS `equipos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `equipos` AS select `equipments`.`id` AS `Id_Equipo`,`equipments`.`internalN` AS `No_Interno`,`v1`.`label` AS `Modelo`,`v2`.`label` AS `Flota`,`v3`.`label` AS `Marca`,`clients`.`name` AS `Cliente`,`projects`.`name` AS `Proyecto` from (((((`equipments` join `valists` `v1` on((`equipments`.`modelo_id` = `v1`.`id`))) join `valists` `v2` on((`equipments`.`flota_id` = `v2`.`id`))) join `valists` `v3` on((`equipments`.`marca_id` = `v3`.`id`))) join `clients` on((`equipments`.`client_id` = `clients`.`id`))) join `projects` on((`equipments`.`project_id` = `projects`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tecnicos`
--

/*!50001 DROP VIEW IF EXISTS `tecnicos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tecnicos` AS select `users`.`id` AS `id_Tecnico`,`users`.`name` AS `Nombre` from (`users` join `activities` on((`users`.`id` = `activities`.`creator_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `componentes`
--

/*!50001 DROP VIEW IF EXISTS `componentes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `componentes` AS select `equipments`.`id` AS `Id_Equipo`,`components`.`id` AS `Id_Compo`,`control_fills`.`value` AS `Consecutivo`,`items`.`name` AS `Name`,`v1`.`label` AS `Familia`,`v2`.`label` AS `Categoria`,`components`.`state` AS `State` from ((((((`equip_has_compos` join `equipments` on((`equip_has_compos`.`equip_id` = `equipments`.`id`))) join `components` on((`equip_has_compos`.`compo_id` = `components`.`id`))) join `control_fills` on((`components`.`id` = `control_fills`.`component_id`))) join `items` on((`components`.`item_id` = `items`.`id`))) join `valists` `v1` on((`items`.`family_id` = `v1`.`id`))) join `valists` `v2` on((`items`.`category_id` = `v2`.`id`))) where (`control_fills`.`valist_id` = 9) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `statuscomp`
--

/*!50001 DROP VIEW IF EXISTS `statuscomp`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `statuscomp` AS select `components`.`id` AS `idComponent`,`components`.`state` AS `Estatus` from `components` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `attrcomponentes`
--

/*!50001 DROP VIEW IF EXISTS `attrcomponentes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `attrcomponentes` AS select `control_fills`.`component_id` AS `idCompo`,`valists`.`label` AS `label`,`control_fills`.`value` AS `val`,`equipments`.`id` AS `idEquip` from ((((`control_fills` join `components` on((`components`.`id` = `control_fills`.`component_id`))) join `valists` on((`valists`.`id` = `control_fills`.`valist_id`))) join `equip_has_compos` on((`equip_has_compos`.`compo_id` = `components`.`id`))) join `equipments` on((`equipments`.`id` = `equip_has_compos`.`equip_id`))) order by `control_fills`.`component_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fact`
--

/*!50001 DROP VIEW IF EXISTS `fact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `fact` AS select `activities`.`id` AS `IdAct`,`activities`.`created_at` AS `Fecha`,`activities`.`equip_id` AS `Id_Equipo`,`activities`.`startDate` AS `Fecha_Inicio`,`activities`.`endDate` AS `Fecha_fin`,`type_activs`.`name` AS `Actividad`,`activities`.`startDate` AS `Hora_Inicio`,`activities`.`endTime` AS `Hora_Fin` from (`activities` join `type_activs` on((`activities`.`type_id` = `type_activs`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `otros_componentes`
--

/*!50001 DROP VIEW IF EXISTS `otros_componentes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `otros_componentes` AS select `equip_has_parts`.`equip_id` AS `IdEquip`,`equip_has_parts`.`item_id` AS `idPart`,`equip_has_parts`.`val` AS `val`,`items`.`name` AS `description`,`v1`.`label` AS `attr` from ((`equip_has_parts` join `items` on((`equip_has_parts`.`item_id` = `items`.`id`))) join `valists` `v1` on((`equip_has_parts`.`attr_id` = `v1`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `participacion`
--

/*!50001 DROP VIEW IF EXISTS `participacion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `participacion` AS select `activities`.`id` AS `id_Act`,`users`.`id` AS `Id_Tecnico` from (`users` join `activities` on((`users`.`id` = `activities`.`creator_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-20 14:07:08
