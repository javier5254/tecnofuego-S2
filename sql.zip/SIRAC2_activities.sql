-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 34.95.168.120    Database: SIRAC2
-- ------------------------------------------------------
-- Server version	5.7.34-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `endDate` date DEFAULT NULL,
  `endTime` time DEFAULT NULL,
  `startDate` date NOT NULL,
  `startTime` time NOT NULL,
  `horometer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `location_id` bigint(20) unsigned DEFAULT NULL,
  `creator_id` bigint(20) unsigned DEFAULT NULL,
  `type_id` bigint(20) unsigned DEFAULT NULL,
  `equip_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_location_id_foreign` (`location_id`),
  KEY `activities_creator_id_foreign` (`creator_id`),
  KEY `activities_type_id_foreign` (`type_id`),
  KEY `activities_equip_id_foreign` (`equip_id`),
  CONSTRAINT `activities_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `activities_equip_id_foreign` FOREIGN KEY (`equip_id`) REFERENCES `equipments` (`id`),
  CONSTRAINT `activities_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `activities_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `type_activs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (105,NULL,NULL,'2021-09-25','09:00:00','12621',0,'2021-09-25 14:13:20','2021-09-25 14:13:20',5,7,1,467),(108,NULL,NULL,'2021-09-20','13:00:00','000',0,'2021-09-28 16:13:42','2021-09-28 16:13:42',8,9,2,1),(109,NULL,NULL,'2021-09-20','13:00:00','000',0,'2021-09-28 16:18:46','2021-09-28 16:18:46',8,9,2,505),(110,'2021-09-20','17:00:00','2021-09-20','13:00:00','000',3,'2021-09-28 16:18:47','2021-09-28 17:22:16',8,9,2,505),(111,NULL,NULL,'2021-09-29','09:00:00','Off',0,'2021-09-29 15:29:33','2021-09-29 15:29:33',13,9,1,714),(112,NULL,NULL,'2021-09-29','09:00:00','Off',0,'2021-09-29 15:29:33','2021-09-29 15:29:33',13,9,1,714),(113,NULL,NULL,'2021-09-29','09:00:00','Off',0,'2021-09-29 15:29:33','2021-09-29 15:29:33',13,9,1,714),(114,'2021-09-29','11:30:00','2021-09-29','09:00:00','Off',3,'2021-09-29 15:29:33','2021-09-29 15:47:54',13,9,1,714),(115,'2021-09-29','16:20:00','2021-09-29','14:00:00','Off',3,'2021-09-29 20:40:50','2021-09-29 20:55:30',14,9,1,474),(116,NULL,NULL,'2021-09-30','15:23:00','333',0,'2021-09-30 20:23:25','2021-09-30 20:23:25',3,5,1,701);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-20 14:05:22
