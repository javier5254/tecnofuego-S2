-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 34.95.168.120    Database: SIRAC2
-- ------------------------------------------------------
-- Server version	5.7.34-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `son` tinyint(1) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `father_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lists_father_id_foreign` (`father_id`),
  CONSTRAINT `lists_father_id_foreign` FOREIGN KEY (`father_id`) REFERENCES `lists` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lists`
--

LOCK TABLES `lists` WRITE;
/*!40000 ALTER TABLE `lists` DISABLE KEYS */;
INSERT INTO `lists` VALUES (1,'Tipo de documento',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(2,'Cargos',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(3,'Atributos de control',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(4,'Familias',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(5,'Categorias',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(6,'Flotas',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(7,'Marcas',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(8,'Sistemas',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(9,'Periocidad',0,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(10,'Locaciones',0,0,'2021-06-03 19:58:21','2021-06-03 19:58:21',NULL),(11,'Modelos',1,1,'2021-06-03 19:58:21','2021-06-03 19:58:21',7),(13,'formatos',1,1,NULL,NULL,NULL),(14,'prueba',0,1,'2021-08-30 20:55:58','2021-08-30 20:55:58',NULL);
/*!40000 ALTER TABLE `lists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-20 14:06:21
