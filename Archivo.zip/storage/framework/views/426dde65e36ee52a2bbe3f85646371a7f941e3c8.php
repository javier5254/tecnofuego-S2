
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?>  | SIRAC 2</title>

    <!-- Favicon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    
    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
</head>

<body>
<div class="app">
    <div class="layout">
       <?php echo $__env->make('layouts.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Page Container START -->
        <div class="page-container" style="background: #EEEEEE;">
           <?php echo $__env->make('layouts.admin.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content Wrapper START -->
            <div class="main-content px-0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                             <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>

                </div>
            </div>
            <!-- Content Wrapper END -->
<!--
           <?php echo $__env->make('layouts.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
-->
        </div>
        <!-- Page Container END -->

    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script type="text/javascript" src="https://unpkg.com/default-passive-events"></script>
<script src="http://momentjs.com/downloads/moment.min.js"></script>

<script src="<?php echo e(url('js/app.js')); ?>"></script>

<!-- BS JavaScript -->

<?php echo $__env->yieldContent('script'); ?>
<!-- page js -->

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/SIRAC-2/resources/views/layouts/admin/app.blade.php ENDPATH**/ ?>