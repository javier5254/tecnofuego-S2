<footer class="content-footer">
    <div class="footer">
        <div class="copyright">
            <span>Copyright © 2017 <b class="text-dark">Theme_Nate</b>. All rights reserved.</span>
            <span class="go-right">
									<a href="" class="text-gray mrg-right-15">Term &amp; Conditions</a>
									<a href="" class="text-gray">Privacy &amp; Policy</a>
								</span>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/SIRAC-2/resources/views/layouts/admin/components/footer.blade.php ENDPATH**/ ?>