<!-- Side Nav START -->
<div class="side-nav">
    <div class="side-nav-inner">

        <ul class="side-nav-menu scrollable">
            <!-- PERFIL QK-->
            <div class="side-nav-logo" style="background-color: #868589;border-right: none;border-bottom: 0">
                <a href="#">
                    <div class="logo logo-dark"></div>
                </a>

            </div>

            <li class="nav-item dropdown">
                <a class="dropdown-toggle shadow-1" href="javascript:void(0);">
                    <span class="icon-holder">
                        <?php if(auth()->user()->profile_photo_path): ?>
                            <img src="<?php echo e(asset('storage') . '/' . auth()->user()->profile_photo_path); ?>" alt=""
                                width="35px" class="img-circle">

                        <?php else: ?>
                            <img src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png"
                                alt="" width="30px">
                        <?php endif; ?>

                    </span>
                    <span class="arrow">
                        <i class="ti-angle-right"></i>
                    </span>
                    <span class="title"><?php echo e(ucwords(auth()->user()->name)); ?></span><br>

                    <span class="title ml-5 pl-2">
                        <?php
                            $rol = auth()->user()->getRolenames();
                            echo $rol->first() != '' ? $rol->first() : 'Sin Rol';
                        ?>
                    </span>


                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="<?php echo e(route('user.show', auth()->user()->id)); ?>">Perfil</a>
                    </li>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();this.closest('form').submit();" class="ml-3">
                                salir
                            </a>
                        </form>
                    </li>

                </ul>
            </li>
            <!-- PERFIL QK-->




            <li class="nav-item">
                <a class="mrg-top-30" href="<?php echo e(route('home.index')); ?>">
                    <span class="icon-holder">
                        <i class="fas fa-home"></i>
                    </span>
                    <span class="title">Principal</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="fas fa-clipboard-list"></i>
                    </span>
                    <span class="title">Actividades</span>
                    <span class="arrow">
                        <i class="ti-angle-right"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="<?php echo e(route('activity.main', 1)); ?>">Inspecciones</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('activity.main', 2)); ?>">Mantenimientos</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('activity.main', 3)); ?>">Recargas</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('activity.main', 4)); ?>">Reinstalacion</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('activity.main', 5)); ?>">Emergencias</a>
                    </li>
                </ul>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['client-show','project-show','component-show','equipment-show'])): ?>
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="fas fa-list-ul"></i>
                    </span>
                    <span class="title">Maestros</span>
                    <span class="arrow">
                        <i class="ti-angle-right"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client-show')): ?>
                        <li>
                            <a href="<?php echo e(route('client.index')); ?>">Clientes</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-show')): ?>
                        <li>
                            <a href="<?php echo e(route('project.index')); ?>">Proyectos</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('component-show')): ?>
                        <li>
                            <a href="<?php echo e(route('component.index')); ?>">Componentes</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipment-show')): ?>
                        <li>
                            <a href="<?php echo e(route('equipment.index')); ?>">Equipos</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user-show','list-show','part-show','serv-show','role-show','permission-show'])): ?>

            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="fas fa-cog"></i>
                    </span>
                    <span class="title">Confirguraciones</span>
                    <span class="arrow">
                        <i class="ti-angle-right"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-show')): ?>
                        <li>
                            <a href="<?php echo e(route('user.index')); ?>">Usuarios</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-show')): ?>
                        <li>
                            <a href="<?php echo e(route('list.index')); ?>">Listas</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('part-show')): ?>
                        <li>
                            <a href="<?php echo e(route('part.index')); ?>">Partes</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('serv-show')): ?>
                        <li>
                            <a href="<?php echo e(route('serv.index')); ?>">Servicios</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-show')): ?>
                        <li>
                            <a href="<?php echo e(route('role.index')); ?>">Roles</a>
                        </li>
                    <?php endif; ?>
                    
                </ul>

            </li>
            <?php endif; ?>
            <li class="nav-item mt-5">
                <a href="index.html">
                    <span class="icon-holder">
                        <i class="fas fa-question-circle"></i>
                    </span>
                    <span class="title">Ayuda</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- Side Nav END -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/SIRAC-2/resources/views/layouts/admin/components/sidebar.blade.php ENDPATH**/ ?>