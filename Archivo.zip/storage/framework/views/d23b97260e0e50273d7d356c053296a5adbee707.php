<!-- Header START -->
<div class="header navbar navbar-fixed-top" id="navbar-custom">
    <div class="header-container">
        <ul class="nav-left">
            <li>
                
                <?php if(trim($__env->yieldContent('volverU'))): ?>
                    <a href="<?php echo e(route('home.index')); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                <?php elseif(trim($__env->yieldContent('volver'))): ?>
                    <a href="<?php echo e(URL::previous()); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                <?php else: ?>
                    <a class="side-nav-toggle" href="javascript:void(0);">
                        <i class="fas fa-bars"></i>
                    </a>
                <?php endif; ?>
            </li>
            <li>
                <a class="title-nav-custom" style="font-weight:600;">
                    <?php echo $__env->yieldContent('breadcum'); ?>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- Header END -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/SIRAC-2/resources/views/layouts/admin/components/navbar.blade.php ENDPATH**/ ?>