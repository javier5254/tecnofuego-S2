<?php $__env->startSection('title', 'Editar Equipo'); ?>
<?php $__env->startSection('breadcum', ' Editar Equipo'); ?>
<?php $__env->startSection('volver', 'si'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-10 offset-lg-1 col-12">
        <div id="alert-container">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h4 class="alert-heading">OPS! <label class="text-lowercase">Parece que faltán campos por llenar...</label>
                    </h4>
                    <hr>
                    <ul class="list-unstyled">
                        <?php
                            $cont = 1;
                        ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-lowercase"><?php echo e($cont++ . '. '); ?><label
                                    class="text-capitalize">El&nbsp;</label><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('equipment.update', $equipment->id)); ?>" method="POST" id="formEquipment">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group mt-4">
                        <div class="row">
                            <div class="col-md-2 offset-md-9">
                                <label for="state" class="float-right">Activo</label>
                            </div>
                            <div class="col-md-1">
                                <div class="toggle-checkbox toggle-success checkbox-inline toggle-sm float-right">
                                    <input type="checkbox" name="state" id="state"
                                        <?php echo e($equipment->state ? 'checked value=1' : ''); ?>>
                                    <label for="state"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="client_id">Cliente</label>
                        <select name="client_id" id="client_id"
                            class="form-control <?php echo e($errors->has('client_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php if(isset($clients)): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($client->id); ?>"
                                        <?php echo e($client->id == $equipment->cname ? 'selected' : ''); ?>><?php echo e($client->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled selected> Sin coincidencias </option>
                                <?php endif; ?>
                            <?php endif; ?>

                        </select>
                        <?php if($errors->has('client_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="project_id">Proyecto</label>
                        <select name="project_id" id="project_id"
                            class="form-control <?php echo e($errors->has('project_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php if(isset($projects)): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($project->id); ?>"
                                        <?php echo e($project->id == $equipment->pname ? 'selected' : ''); ?>><?php echo e($project->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled selected> Sin coincidencias </option>
                                <?php endif; ?>
                            <?php endif; ?>

                        </select>
                        <?php if($errors->has('project_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="flota_id">Flota</label>
                        <select name="flota_id" id="flota_id"
                            class="form-control <?php echo e($errors->has('flota_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php $__empty_1 = true; $__currentLoopData = $valists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($flota->list_id == 6): ?>
                                    <option value="<?php echo e($flota->id); ?>"
                                        <?php echo e($flota->id == $equipment->flota ? 'selected' : ''); ?>><?php echo e($flota->label); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled selected> Sin coincidencias </option>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('flota_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="form-group">
                        <label for="marca_id">Marca</label>
                        <select name="marca_id" id="marca_id"
                            class="form-control <?php echo e($errors->has('marca_id') ? 'is-invalid' : ''); ?>"
                            onchange="valuesBrand(this.value)">
                            <option disabled selected> </option>
                            <?php $__empty_1 = true; $__currentLoopData = $valists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($marca->list_id == 7): ?>
                                    <option value="<?php echo e($marca->id); ?>"
                                        <?php echo e($marca->id == $equipment->marca ? 'selected' : ''); ?>><?php echo e($marca->label); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled selected> Sin coincidencias </option>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('marca_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="form-group">
                        <label for="modelo_id">Modelo</label>
                        <select name="modelo_id" id="modelo_id"
                            class="form-control <?php echo e($errors->has('modelo_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php $__empty_1 = true; $__currentLoopData = $valists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($modelo->list_id == 11): ?>
                                    <option value="<?php echo e($modelo->id); ?>"
                                        <?php echo e($modelo->id == $equipment->modelo ? 'selected' : ''); ?>><?php echo e($modelo->label); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled selected> Sin coincidencias </option>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('modelo_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="form-group">
                        <label for="numberI">Numero interno </label>
                        <input type="number" name="internalN" id="internalN" class="form-control"
                            value="<?php echo e($equipment->internalN); ?>">
                    </div>
                    <div class="form-group">
                        <label for="sistema_id">Sistema</label>
                        <select name="sistema_id" id="sistema_id"
                            class="form-control <?php echo e($errors->has('sistema_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php $__empty_1 = true; $__currentLoopData = $valists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sistema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($sistema->list_id == 8): ?>
                                    <option value="<?php echo e($sistema->id); ?>"
                                        <?php echo e($sistema->id == $equipment->sistema ? 'selected' : ''); ?>>
                                        <?php echo e($sistema->label); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled selected> Sin coincidencias </option>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('sistema_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="form-group">
                        <label for="horometer">Horómetro</label>
                        <input type="text" name="horometer" id="horometer"
                            class="form-control <?php echo e($errors->has('horometer') ? 'is-invalid' : ''); ?>"
                            value="<?php echo e($equipment->horometer); ?>">
                        <?php if($errors->has('horometer')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="periodicidad_id">Periodicidad</label>
                        <select name="periodicidad_id" id="periodicidad_id"
                            class="form-control <?php echo e($errors->has('periodicidad_id') ? 'is-invalid' : ''); ?>">
                            <option disabled selected> </option>
                            <?php $__empty_1 = true; $__currentLoopData = $valists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($p->list_id == 9): ?>
                                    <option value="<?php echo e($p->id); ?>"
                                        <?php echo e($p->id == $equipment->periodicidad ? 'selected' : ''); ?>><?php echo e($p->label); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option disabled selected> Sin coincidencias </option>
                            <?php endif; ?>
                        </select>
                        <?php if($errors->has('periodicidad_id')): ?>
                            <div class="invalid-feedback">
                                Ingresa un nombre..
                            </div>
                        <?php else: ?>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        <?php endif; ?>

                    </div>




            </div>
        </div>
        
        <div class="card">
            <h4 class="ml-4 mt-4">Componentes</h4>
            <h5><a href="#" data-toggle="modal" data-target="#modal-md" class="btn btn-success btn-sm my-4 ml-4"><i
                        class="fas fa-plus"></i> &nbsp; Agregar Componente</a></h5>

            <form action="" method="get" id="form_search">
                <div class="form-group input-group mb-0">
                    <?php echo csrf_field(); ?>
                    <div class="form-group input-group mb-0">
                        <input id="SearchList" type="text" class="form-control mb-0 border" placeholder="Buscar..">
                        <span class="input-group-text"><a href=""><i class="fas fa-search"></i></span>
                    </div>
                </div>
            </form>

            <div class="row p-0 m-0" id="contenendorC" style="overflow: auto;height:300px;">


                <?php $__empty_1 = true; $__currentLoopData = $componentsEquip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="card-body border bottom col-12" id="contain<?php echo e($ce->id); ?>">
                        <div class="row">
                            <a class="col-sm-8 col-lg-9">
                                <h4 style="m-0">
                                    <?php echo e($ce->iname); ?>

                                </h4>
                                <small class="text-custom">
                                    Serial: <?php echo e($ce->value); ?>

                                </small><br>
                                <small class="mb-0 text-custom">
                                    <?php echo e($ce->cname); ?> | <?php echo e($ce->pname); ?>

                                </small>
                            </a>
                            <a class="col-sm-4 col-lg-2 btndynamic" href="#" data-toggle="modal"
                                data-target="#modal-md<?php echo e($ce->id); ?>" id="<?php echo e($ce->id); ?>">
                                <h5 class="text-center">
                                    <small>
                                        <small>
                                            <?php echo e(date('d/m/Y', strtotime($ce->created_at))); ?>

                                        </small>
                                        <div class="mt-1"><?php echo QrCode::size(30)->generate(Request::url('component.edit', $ce->id)); ?></div>
                                    </small>
                                </h5>
                            </a>
                            <div class="col-lg-1">
                                <button id="<?php echo e($ce->id); ?>"
                                    class="btn btn-danger btn-inverse btn-rounded float-right mt-3"
                                    onclick="removeCompo(this.id)"><i class="fas fa-times"></i></button>
                            </div>
                            <div class="modal fade" id="modal-md<?php echo e($ce->id); ?>">
                                <div class="modal-dialog modal-md" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="padding-5">
                                                <div class="row">
                                                    <div class="my-auto mx-auto px-4 py-2">
                                                        <?php echo QrCode::size(140)->generate(route('component.edit', $ce->id)); ?>

                                                        <button class="btn btn-secondary text-white d-block center mt-4"
                                                            href="#" onclick="imprimir()"><i class="fas fa-print"></i>
                                                            imprimir
                                                            QR </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <a href="#" class="card-body" style="border-bottom: 1px solid #ccc">
                        <div class="row">
                            <div class="col-md-10 offset-md-1">
                                <h5 class="text-center text-gray">No se encontrarón registros</h5>

                            </div>

                        </div>
                    </a>
                <?php endif; ?>

                
            </div>

        </div>
        
        <div class="card">
            <h4 class="ml-4 mt-4">Otros componentes</h4>
            <h5><a href="#" data-toggle="modal" data-target="#modal2-md" class="btn btn-success btn-sm my-4 ml-4"><i
                        class="fas fa-plus"></i> &nbsp; Agregar Servicio</a></h5>

            <form action="" method="get" id="form_search">
                <div class="form-group input-group mb-0">
                    <?php echo csrf_field(); ?>
                    <div class="form-group input-group mb-0">
                        <input id="SearchList" type="text" class="form-control mb-0 border" name="SearchList"
                            placeholder="Buscar..">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
            </form>

            <div class="row m-0 p-0" id="contenendorS">
                <?php $__empty_1 = true; $__currentLoopData = $servs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="panel panel-default col-12 p-0 border">
                        <div class="panel-heading" role="tab" id="heading-2-One">
                            <div class="row m-3">
                                <div class="col-11">
                                    <a class="" data-toggle="collapse" data-parent="#accordion-2"
                                        href="#collapse-<?php echo e($s->id); ?>" aria-expanded="true">
                                        <h4 style="m-0">
                                            <?php echo e($s->name); ?>

                                        </h4>
                                        <small class="text-custom">
                                            No parte: <?php echo e($s->partNum); ?>

                                        </small>
                                    </a>
                                </div>
                                <div class="col-lg-1">
                                    <button id="compos<?php echo e($s->id); ?>"
                                        class="btn btn-danger btn-inverse btn-rounded float-right"
                                        onclick="removeServ(this.id)"><i class="fas fa-times"></i></button>
                                </div>
                            </div>

                        </div>
                        <div id="collapse-<?php echo e($s->id); ?>" class="panel-collapse collapse" style="">
                            <div class="panel-body p-5 border top">
                                <label for=""><?php echo e($s->label); ?></label>
                                <input type="date" value="<?php echo e($s->val); ?>" id="name" class="form-control">
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <a href="#" class="card-body" style="border-bottom: 1px solid #ccc">
                        <div class="row">
                            <div class="col-md-10 offset-md-1">
                                <h5 class="text-center text-gray">No se encontrarón registros</h5>

                            </div>

                        </div>
                    </a>
                <?php endif; ?>


            </div>

        </div>
        
        <div class="pull-right">
            <a href="<?php echo e(route('equipment.index')); ?>" class="btn btn-link">Cancelar</a>
            <button type="button" class="btn btn-success btn-sm" id="btnsave">Guardar</button>
            </form>
        </div>
        
        <div class="modal fade" id="modal-md">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content">
                    <div class="modal-body p-0 py-4">

                        <div class="row">
                            <div class="col-12">
                                <form action="" method="get" id="form_search">
                                    <div class="form-group input-group mb-0">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group input-group mb-0">
                                            <input id="SearchList" type="text" class="form-control mb-0 border"
                                                name="SearchList" placeholder="Buscar..">
                                            <span class="input-group-text"><a href=""><i class="fas fa-search"></i></span>
                                        </div>
                                    </div>
                                </form>

                                <div class="row m-0 p-0" id="contenendor" style="overflow: auto;height:300px;">
                                    <?php $__empty_1 = true; $__currentLoopData = $components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                        <div class="card-body border bottom col-12">
                                            <div class="row">
                                                <div class="checkbox col-1 pl-4">
                                                    <input class="compos" type="checkbox"
                                                        id="compo[<?php echo e($component->id); ?>]" value="<?php echo e($component->id); ?>">
                                                    <label for="compo[<?php echo e($component->id); ?>]"></label>
                                                </div>
                                                <div class="col-md-9">

                                                    <h5 style="mb-0">
                                                        <?php echo e($component->name); ?>

                                                        <input type="hidden" name="" id="name<?php echo e($component->id); ?>"
                                                            value="<?php echo e($component->name); ?>">

                                                    </h5>

                                                    <small class="mb-0 text-custom">
                                                        Serial: <?php echo e($component->value); ?>

                                                        <input type="hidden" name="" id="serial<?php echo e($component->id); ?>"
                                                            value="<?php echo e($component->value); ?>">


                                                    </small><br>
                                                    <small class="mb-0 text-custom">
                                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($client->id = $component->client_id): ?>
                                                            <?php echo e($client->name . ' | '); ?>

                                                            <input type="hidden" id="client<?php echo e($component->id); ?>"
                                                                value="<?php echo e($client->name . ' | '); ?>">
                                                        <?php break; ?>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($project->id = $component->project_id): ?>
                                                            <?php echo e($project->name . ' | '); ?>

                                                            <input type="hidden" id="project<?php echo e($component->id); ?>"
                                                                value="<?php echo e($project->name . ' | '); ?>">
                                                        <?php break; ?>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($component->state ? 'Activo' : 'Inactivo'); ?>

                                                    <input type="hidden" id="state<?php echo e($component->id); ?>"
                                                        value="<?php echo e($component->state ? 'Activo' : 'Inactivo'); ?>">
                                                    </small>
                                                </div>
                                                <div class="col-2" href="#" data-toggle="modal"
                                                    data-target="#modal-md<?php echo e($component->id); ?>" id="<?php echo e($component->id); ?>">
                                                    <h5 class="text-center">
                                                        <small>
                                                            <small>
                                                                <?php echo e(date('M,d,Y', strtotime($component->created_at))); ?>

                                                                <input type="hidden" id="date<?php echo e($component->id); ?>"
                                                                    value="<?php echo e(date('M,d,Y', strtotime($component->created_at))); ?>">
                                                            </small>
                                                            <div class="mt-1">
                                                                <?php echo QrCode::size(30)->generate(Request::url('component.edit', $component->id)); ?>

                                                            </div>
                                                        </small>
                                                    </h5>


                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <a href="#" class="card-body" style="border-bottom: 1px solid #ccc">
                                            <div class="row">
                                                <div class="col-md-10 offset-md-1">
                                                    <h5 class="text-center text-gray">No se encontrarón registros</h5>

                                                </div>

                                            </div>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="d-block px-3">
                        <button id="btnaddComp" type="button" class="btn btn-success btn-sm float-right"
                            data-dismiss="modal">Agregar</button>
                        <button data-dismiss="modal" class="btn btn-link float-right" type="buttoin">Cancelar</button>
                    </div>
                </div>
        </div>
    </div>
    
    <div class="modal fade" id="modal2-md">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="padding-5">
                        <div class="row">
                            <div class="col-12">
                                <form action="" method="get" id="form_search">
                                    <div class="form-group input-group mb-0">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group input-group mb-0">
                                            <input id="SearchList" type="text" class="form-control mb-0 border"
                                                name="SearchList" placeholder="Buscar..">
                                            <span class="input-group-text"><a href=""><i class="fas fa-search"></i></span>
                                        </div>
                                    </div>
                                </form>

                                <div class="row col-12 m-0 p-0" id="contenendor">
                                    <?php $__empty_1 = true; $__currentLoopData = $servs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a class="card-body" style="border-bottom: 1px solid #ccc">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <div class="checkbox">
                                                        <input id="task10" name="task10" type="checkbox">
                                                        <label for="task10"></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5><?php echo e($serv->name); ?></h5>
                                                    <span>Estado:
                                                        <?php echo e($serv->state == 1 ? 'Activo' : 'Inactivo'); ?></span><br>

                                                </div>
                                                <div class="col-md-2">
                                                    <span class="float-right">
                                                        Mar 09 2020
                                                    </span>
                                                </div>

                                            </div>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <a href="#" class="card-body" style="border-bottom: 1px solid #ccc">
                                            <div class="row">
                                                <div class="col-md-10 offset-md-1">
                                                    <h5 class="text-center text-gray">No se encontrarón registros</h5>

                                                </div>

                                            </div>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-block px-3">
                    <button type="submit" class="btn btn-success btn-sm float-right">Guardar</button>
                    <button data-dismiss="modal" class="btn btn-link float-right" type="buttoin">Cancelar</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("#internalN").blur(function() {
            let internalN = this.value;
            let icon, type, mesaje;
            var project_id = $("#project_id").val();
            if (project_id) {
                $.ajax({
                    url: "<?php echo e(route('equipment.validateN')); ?>",
                    type: 'POST',
                    data: {
                        "project_id": project_id,
                        "value": internalN,
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    success: function(res) {
                        var val = JSON.parse(res)
                        if (val == null) {
                            icon = '<i class="far fa-check-circle"></i>';
                            type = "alert-success";
                            mensaje = "El campo número interno se encuentra disponible";
                        } else {
                            icon = '<i class="far fa-times-circle"></i>';
                            type = "alert-danger";
                            mensaje = "El campo número interno se encuentra ocupado";
                        }
                        $('#alert-container').html('');
                        var todo = '<div class="alert ' + type +
                            ' alert-dismissible fade show" role="alert">';
                        todo +=
                        '<h4 class="alert-heading text-lowercase" style="text-transform:none;">';
                        todo += icon + '&nbsp;&nbsp;';
                        todo += mensaje + '</h4>';
                        todo +=
                            '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
                        todo += '<span aria-hidden="true">&times;</span>';
                        todo += '</button>';
                        todo += '</div>';
                        $('#alert-container').append(todo);
                    }
                });
            }
        });
        function valuesBrand(value) {

            if (value != '') {
                $.ajax({
                    url: "<?php echo e(route('equipment.showModelos')); ?>",
                    type: 'POST',
                    data: {
                        "value": value,
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    success: function(res) {
                        var val = JSON.parse(res)
                        $('#modelo_id').html("");
                        $('#modelo_id').append($('<option>', {
                            value: null,
                            text: "seleccione una opcion"
                        }));
                        for (let x = 0; x < val.length; x++) {
                            id = val[x].id;
                            label = val[x].label;
                            $('#modelo_id').append($('<option>', {
                                value: id,
                                text: label
                            }));
                        }
                    }
                });
            }
        }

        function removeNew(id) {
            $("#" + id).remove();
            $("#data" + id).remove();
        }

        function removeCompo(id) {
            $.ajax({
                url: "<?php echo e(route('equipment.deleteCompo')); ?>",
                type: 'POST',
                data: {
                    "compo_id": id,
                    "equip_id": "<?php echo e($equipment->id); ?>",
                    "_token": "<?php echo e(csrf_token()); ?>",
                },
                success: function(res) {
                    $("#contain" + id).remove();
                    $("#" + id).remove();
                    $("#data" + id).remove();

                }
            });
        }
        $('#btnsave').click(function() {
            $("#formEquipment").submit();
        });
        $('#btnaddComp').click(function() {

            let compos = [];
            let compovals;

            $("#contenendorC").html('');

            $(".compos:checkbox:checked").each(function() {
                compos.push($(this).val());

            });
            if (compos) {
                compos.forEach(function(compo, index) {
                    compovals = ('<a class="card-body" style="border-bottom: 1px solid #ccc">');
                    compovals += ('<div class="row">');
                    compovals += ('<div class="col-md-10">');
                    compovals += ('<h5>' + compos[index] + '</h5>');
                    compovals += ('<span>Estado: Activo</span>');
                    compovals += ('</div>');
                    compovals += ('<div class="col-md-2">');
                    compovals += ('<span class="float-right">Mar 09 2020</span>');
                    compovals += ('');
                    compovals += ('</div>');
                    compovals += ('</div>');
                    compovals += ('</a>');
                    $("#contenendorC").append(compovals);
                });
            }

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/SIRAC-2/resources/views/modules/equipment/edit.blade.php ENDPATH**/ ?>